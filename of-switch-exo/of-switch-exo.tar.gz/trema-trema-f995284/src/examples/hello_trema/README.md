See https://www.relishapp.com/trema/trema/docs/examples/hello-trema-example

