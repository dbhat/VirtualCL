import os
PKGDATADIR = os.environ.get("OVS_PKGDATADIR", """/opt/trema-trema-f995284/objects/openvswitch/share/openvswitch""")
RUNDIR = os.environ.get("OVS_RUNDIR", """/opt/trema-trema-f995284/tmp/sock""")
LOGDIR = os.environ.get("OVS_LOGDIR", """/opt/trema-trema-f995284/objects/openvswitch/var/log/openvswitch""")
BINDIR = os.environ.get("OVS_BINDIR", """/opt/trema-trema-f995284/objects/openvswitch/bin""")
